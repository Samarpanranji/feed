<?php
session_start();
include 'connect.php';

// Optional: restrict to admin only
// if (!isset($_SESSION['admin'])) {
//     echo "<script>alert('Access denied. Please login as admin.'); window.location.href='adminlogin.php';</script>";
//     exit();
// }

// Correct query based on actual column names in your DB
$sql = "SELECT firstName, lastName, email FROM users";
$result = $conn->query($sql);

// Check query
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Users</title>
    <style>
        
        * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
      padding: 0;
    }

    header {
      background-color: #2f4f4f;
      color: white;
      padding: 20px 0;
      text-align: center;
    }

    nav {
      background-color: #333;
      width: 100%;
    }

    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    nav .left,
    nav .right {
      display: flex;
      gap: 10px;
      align-items: center;
    }

    nav li {
      list-style: none;
    }

    nav a {
      display: block;
      color: white;
      text-decoration: none;
      padding: 14px 20px;
    }

    nav a:hover {
      background-color: #111;
    }

    nav a.active {
      background-color: #02f92fff;
    }

    main {
      padding: 20px;
    }

    h2.section-title {
      margin: 20px 0 10px;
      color: #2f4f4f;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 40px;
      background-color: #fff;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ccc;
      text-align: left;
    }

    th {
      background-color: #2f4f4f;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    button {
      background: red;
      color: white;
      border: none;
      padding: 6px 10px;
      cursor: pointer;
      border-radius: 4px;
    }

    button:hover {
      opacity: 0.85;
    }

    .datetime-column {
      width: 140px;
      white-space: nowrap;
    }

    @media (max-width: 768px) {
      nav ul {
        flex-direction: column;
        align-items: flex-start;
      }

      nav .left, nav .right {
        flex-direction: column;
        align-items: flex-start;
        width: 100%;
      }

      nav a {
        width: 100%;
      }
    }



        h1 {
            text-align: center;
            color: #f3f7f7ff;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #ccc;
            text-align: center;
        }

        th {
            background-color: #2f4f4f;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #2f4f4f;
            text-decoration: none;
            font-weight: bold;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
    <h1>E-COMPLAINT AND FEEDBACK SYSTEM</h1>
  </header>

  <nav>
    <ul>
      <div class="left">
        <li><span style="color:white; font-size: 20px; font-weight: bold;">Registered Users</span></li>
      </div>
      <div class="right">
        <li><a class="active" href="adminhome.php">Back</a></li>
      </div>
    </ul>
  </nav>

<?php
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>First Name</th><th>Last Name</th><th>Email</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            
            <td>{$row['firstName']}</td>
            <td>{$row['lastName']}</td>
            <td>{$row['email']}</td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "<p style='text-align:center;'>No users found.</p>";
}

$conn->close();
?>
</body>
</html>
