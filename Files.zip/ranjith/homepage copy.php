<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">

</head>
<body>

 <header>
    <br/><h1>E-COMPLAINT AND FEEDBACK SYSTEM</h1><br/>
    </header>


    <nav>
      <ul>
       <li style="float:right"><a class="active" href="index.php">logout</a></li>
        <li style="float:right"><a href="#contact">Contact</a></li>
        <li style="float:right"><a href="#news">home</a></li>
        
      </ul>
    </nav><br/><br/><br/>

<main>
<br/><h1>HELLO USER</h1><br/>
</main>


</body>
</html> 